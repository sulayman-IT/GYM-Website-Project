<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Package</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }
        h1.h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            margin-left: 45px;
            
        }
        p.h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            margin-left: 25px;
        }
        .cn{
            text-align: center;
        }
        form{
            margin: auto;
            width:75%;
            background-color: rgba(255, 255, 255, 0.8);
        }
        a.gb{
            border: 2px solid #feffff;
            padding: 2px 10px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 14px;
            margin-left: 35px;
        }
        a.gb:visited {
            text-decoration: none;
        }
        a.gb:link {
            text-decoration: none;
        }
        a.gb:active{
            text-decoration: none;
        }
        a.gb:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
        table{
            width:75%;
            border-collapse: collapse;
            border-style: solid;
            border-color: black;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:nth-child(odd) {
            background-color: rgb(128, 128, 128, 0.6);
        }
        th {
            background-color:black;
            color: white;
            padding: 10px;
        }
        td{
            text-align: center;
            padding: 8px 15px;
        }
        .del{
            background-color: red;
            color: black;
            padding: 3px 18px;
            border-radius: 3px;
            border-color: red;
        }
        .del:hover{
            background-color: #8B0000;
            color: white;
            border-color: #8B0000;
            border-radius: 3px;
        }

    </style>
</head>
<body>
    <h1 class="h11">Hyper GYM</h1>
    <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
    <br><br>
    <form action="" method="post">
        <center>
            <br>
            <h2>Membership List Packages</h2>
            <table border="2">
                <tr>
                    <th>Package name</th>
                    <th>Price</th>
                    <th>Operation</th>
                </tr>
                <?php 
                    include './check.php'; 

                    $contodb = mysqli_connect('localhost', 'dbuser', 'dbpass', 'gym');

                    if (mysqli_connect_errno()) {
                        echo '<script>alert("ERROR, No Connection")</script>';
                    }
                    else{
                        $lpquery = mysqli_query($contodb, "SELECT packageName, packagePrice FROM operations")
                        or exit("Query ERROR!");

                        while ($x = mysqli_fetch_assoc($lpquery)) {
                            echo '<tr>';
                            echo '<td>' . $x['packageName'] . '</td>';
                            echo '<td>' . $x['packagePrice'] . '</td>';
                            echo '<td><input type="submit" name="delete" class="del" value="Delete"></td>';
                            echo '<input type="hidden" name="packageName" value="' . $x["packageName"] . '">';
                            echo '</tr>';
                        }
                    }
                    if (isset($_POST['delete'])) {

                        $packname = $_POST['packageName'];
                        header("Refresh:0");

                        $delsql = "DELETE FROM operations WHERE packageName='$packname'";
                        mysqli_query($contodb, $delsql)
                        or exit("Query ERROR!");
                    }
                    mysqli_close($contodb);       
                    ?>
            </table>
            <br><br>
        </center>
        <br><br><br>
    </form>
    <br><br>
    <a href="main.php" class="gb">Go back</a>
</body>
</html>