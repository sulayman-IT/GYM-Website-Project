<?php 
include './check.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body{
            background-color: rgba(0, 172, 184, 0.881);
        }
        .foter{
            text-align: right;
            
        }
        .sm{
            margin-right: 120px;
        }
        a{
            margin-left: 7px;
            margin-right: 7px;
        }
        h1, p{
            margin-left: 40px;
        }
        .pp{
            margin-left: 60px;
        }
        .md{
            height: 250px;
            width: 250px;
            margin-left: 750px;
        }
        .aa{
            margin-right: 50px;
        }
        .gb{
            margin-right: 900px;
            border: 2px solid #feffff;
            padding: 1px 10px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 14px;
        }
        a.gb:visited {
            text-decoration: none;
        }
        a.gb:link {
            text-decoration: none;
        }
        a.gb:active{
            text-decoration: none;
        }
        a.gb:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
    </style>
</head>
<body>
    <br><br>
    <h1>Information about Hyber GYM</h1>
    <br><p><b>Welcome to our gym website, firstly some information about history:</b></p><p class="pp">
    This GYM found in July 2000 and it has seven Gold medals and three silver medals. <br>
        here you can become a memeber and you can get trained by the most profassional coaches in the country.</p>
    <br><br>
    <img src="images/Gmedal.png" class="md">
    <p>For more <b>daily tips</b> and performances, please follow out pages on socail media below:</p>
    
    <footer>
        <div class="foter">
            <hr>
            <a href="main.php" class="gb">back</a>
            <a href="https://www.facebook.com">
                <img src="images/fblogo.png" height="30px" width="30px">
            </a>
            <a href="https://www.instagram.com">
                <img src="images/inslogo.png" height="30px" width="30px">
            </a>
            <a href="https://www.twitter.com" class="aa">
                <img src="images/twtlogo.png" height="30px" width="30px">
            </a>
            
        </div>
    </footer>
</body>
</html>