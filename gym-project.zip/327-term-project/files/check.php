<?php
session_start();
if (!isset($_SESSION['check']) && $_SESSION['check'] != 'ok'){
    header('location:signin.php');
    exit;
}
?>