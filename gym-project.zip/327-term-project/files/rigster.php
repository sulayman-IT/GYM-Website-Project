<?php
if(isset($_POST['register'])){
    session_start(); 

    $contodb = mysqli_connect('localhost','dbuser','dbpass', 'gym');
    if (mysqli_connect_errno()) {
        echo "Connection to database failed!!";
    } 
    else {
        $un = $_POST['username'];
        $pwd = $_POST['password'];
        $fn = $_POST['fullname'];
        $em = $_POST['email'];
        $g = $_POST['gender'];
        $bd = $_POST['dob'];

        $query = "INSERT INTO members (username,password,full_name,email,gender,birthdate) VALUES (?,?,?,?,?,?)";

        $stmt = mysqli_stmt_init($contodb);
        mysqli_stmt_prepare($stmt, $query)
        or exit('Query Error!! check your query'. mysqli_stmt_errno($stmt));

        mysqli_stmt_bind_param($stmt, 'ssssss', $un, $pwd, $fn, $em, $g, $bd)
        or exit('Bind Param Error.');

        mysqli_stmt_execute($stmt)
        or exit('Query Execution failed.'. mysqli_stmt_errno($stmt));

        if (mysqli_stmt_affected_rows($stmt) == 1) {
            header("location:signin.php");
        } else {
            header("location:rigster.php");
        }
        mysqli_stmt_close($stmt);
        mysqli_close($contodb);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rigster</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }

        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 10px;
        }

        .left {
            left: 0;
            width: 30%;
        }

        .right {
            right: 0;
            width: 70%;
        }
        h1.h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            text-align: right;
        }
        p.h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            text-align: center;
        }
        form{
            background-color:cadetblue;
            width: 48%;
            height: 450px;
            margin-right: 50px;
            margin-top: 100px;
            float:right;
            border: solid;
            border-color: black;
        }
        .fo{
            margin: 15px;
        }
        a{
            border: 2px solid #feffff;
            padding: 2px 10px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 14px;
            margin-left: 35px;
        }
        a:visited {
            text-decoration: none;
        }
        a:link {
            text-decoration: none;
        }
        a:active{
            text-decoration: none;
        }
        a:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
        .reg{
            background-color: black;
            color: white;
            padding: 5px 20px;
            border-radius: 10px;
        }
        .reg:hover{
            background-color: #2f2f2f;
            color: white;
            border-color: #2f2f2f;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="split right">
        <div class="centered">
            <form method="post">
                <center>
                    <h2>Rigstration</h2>
                </center>
                <br>
                <p class="fo">
                    Full Name:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="fullname" id="rfni" required="">
                    <br><br>
                    e-mail:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="email" name="email" id="rsei" required="">
                    <br><br>        
                    Gender:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <select name="gender" id="rgi">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select><br><br>
                    Date Of Birth:&nbsp&nbsp<input type="date" name="dob" id="rdobi">
                    <br><br><br>
                    User Name:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="username" id="runi" required="">
                    <br><br>
                    Password:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="password" name="password" id="rpwsi" required="">
                    <br><hr><br>  
                    <center>
                        <button type="submit" name="register" class="reg" onclick="alert('You are register now\n sign in please')">Rigster</button>
                    </center>
                    <a href="signin.php" class="fo">Go back</a>
                </p>
            </form>
        </div>
    </div>
    <div class="split left">
        <div class="centered">
            <h1 class="h11">Hyper GYM</h1>
            <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
        </div>
    
</body>
</html>