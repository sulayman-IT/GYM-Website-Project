<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }

        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 10px;
        }

        .left {
            left: 0;
            width: 30%;
        }

        .right {
            right: 0;
            width: 70%;
        }
        h1.h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            text-align: right;
        }
        p.h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            text-align: center;
        }
        form{
            background-color:cadetblue;
            width: 85%;
            height: 430px;
            margin-left: 15px;
            border: solid;
            border-color: black;
        }
        .fo{
            margin: 15px;
        }
        .n{
            display: inline-block;
            text-decoration: none;
            background: #000000;
            padding: 5px 20px;
            border-radius: 5px;
            font-family: halvita;
            font-weight: bold;
            color: #fff;
            box-shadow: 0 5px 0 #2f2f2f;
            transition: all 0.2s;
        }
        .n:active{
            transform: translateY(3px);
            box-shadow: 0 3px 0 #000000;
        }
        .logbtn{
            background-color: black;
            color: white;
            padding: 5px 20px;
            border-radius: 6px;
        }
        .logbtn:hover{
            background-color: #2f2f2f;
            color: white;
            border-color: #2f2f2f;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="split right">
        <div class="centered">

        </div>
    </div>
    <div class="split left">
        <div class="centered">
            <h1 class="h11">Hyper GYM</h1>
            <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
                <form action="signin2.php" method="post">
                    <br><br>
                    <center>
                        <h1 class="fo">Sign-in</h1>
                    </center>
                    <br><br>
                    <p class="fo">User Name: <input type="text" name="username" id="uni" required=""></p>
                    <p class="fo">Password: &nbsp&nbsp <input type="password" name="password" id="spwdi" ></p>
                    <br><br>
                    <center>
                        <button type="submit" name="submit" class="logbtn">Log in</button>
                        <br><br><br><br>
                        <a href="rigster.php" class="n">Rigster Now</a>
                    </center>
                </form>
        </div>
    </div>
</body>
</html>