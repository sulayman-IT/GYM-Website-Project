<?php 
include './check.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }

        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 10px;
        }

        .left {
            left: 0;
            width: 30%;
        }

        .right {
            right: 0;
            width: 70%;
        }
        h1.h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            text-align: right;
        }
        p.h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            text-align: center;
        }
        a.c{
            border: 2px solid #feffff;
            padding: 15px 55px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            color: white;
            display: inline-block;
            font-size: 16px;
            margin-left: 35px;
        }
        a.cs{
            border: 2px solid #feffff;
            padding: 15px 19px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 16px;
            margin-left: 35px;
        }
        a.cc{
            border: 2px solid #feffff;
            padding: 15px 58px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            color: white;
            display: inline-block;
            font-size: 16px;
            margin-left: 35px;
        }
        a.cl{
            border: 2px solid #feffff;
            padding: 15px 44px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            color: white;
            display: inline-block;
            font-size: 16px;
            margin-left: 35px;
        }
        
        a:hover{
            text-decoration: none;
            color: rgb(0, 211, 211);;
            background-color: black;
            border-color: black;
        }
        a:visited {
            text-decoration: none;
        }
        a:link {
            text-decoration: none;
        }
        a:active{
            text-decoration: none;
        }
        a.lo{
            border: 2px solid #feffff;
            padding: 5px 15px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 14px;
            margin-left: 35px;
        }
        a.lo:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
    </style>
</head>
<body>
    <div class="split right">
        <div class="centered">
        </div>
    </div>
    <div class="split left">
        <div class="centered">
            <h1 class="h11">Hyper GYM</h1>
            <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
                <form action="" method="post">
                    <br><br>    
                    <a href="member.php" class="cc"> Member </a>
                    <br><br>
                    <a href="addpackage.php" class="cs">Customize packages</a>
                    <br><br>
                    <a href="listpackage.php" class="cl">List Package</a>
                    <br><br>
                    <a href="aboutus.php" class="c">About Us</a>
                    <br><br><br><br>
                    <a href="logout.php" class="lo">Log out</a>
                </form>
        </div>
    </div>
</body>
</html>