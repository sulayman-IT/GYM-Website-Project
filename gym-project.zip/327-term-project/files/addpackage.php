<?php
include './check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Package</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }

        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 10px;
        }

        .left {
            left: 0;
            width: 30%;
        }

        .right {
            right: 0;
            width: 70%;
        }
        .h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            text-align: right;
        }
        .h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            text-align: center;
        }
        form{
            margin: auto;
            margin-top: 120px;
            background-color:rgb(95,158,160, 0.95);
            width: 80%;
            height: 430px;
            border: solid;
            border-color: black;
            border-radius: 5px;
        }
        .fo{
            margin: 15px;
        }
        .h1h{
            font-family: "Times New Roman", Times, serif;
            text-align: center;
        }
        tr,td{
            text-align: left;
        }
        table{
            margin: auto;
            width: 70%;
        }
        .gb{
            margin-right: 900px;
            border: 2px solid #feffff;
            padding: 2px 12px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 16px;
            margin-left: 25px;
        }
        a.gb:visited {
            text-decoration: none;
        }
        a.gb:link {
            text-decoration: none;
        }
        a.gb:active{
            text-decoration: none;
        }
        a.gb:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
        .ll{
            text-align: right;
            font-size: large;
        }
        .btncreate{
            background-color: black;
            color: white;
            padding: 5px 18px;
        }
        .btncreate:hover{
            background-color: #2f2f2f;
            color: white;
            border-color: #2f2f2f;
            
        }
    </style>
</head>
<body>
    <div class="split right">
        <div class="centered">
        <form action="addpackage2.php" method="post">
            <br>
                <h1 class="h1h">Create Package</h1>
                <br><br>
                <table>
                    <tr>
                        <th class="ll">Package name:</th>
                            <td><input type="text" name="packname" id="packname" required></td>
                    </tr>
                    <tr>
                        <th class="ll">Starting Time:</th>
                            <td><input type="time" name="starttime" id="starttime" required></td>
                    </tr>
                    <tr>
                        <th class="ll">Ending Time:</th>
                            <td><input type="time" name="endtime" id="endtime" required></td>
                    </tr>
                    <tr>
                        <th class="ll">Price:</th>
                        <td><input type="number" name="price" id="price" required></td>
                    </tr>
                </table>
                <br><br>
                <center>
                    <button type="submit" name="submit" class="btncreate" onclick="alert('you have successfully add the Package')">Create</button>
                </center>
                <br><br><br><br>
                <a href="main.php" class="gb">back</a>
            </form> 
        </div>
    </div>
    <div class="split left">
        <div class="centered">
            <h1 class="h11">Hyper GYM</h1>
            <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
            
        </div>
    </div>
</body>
</html>