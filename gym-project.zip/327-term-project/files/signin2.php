<?php
session_start();

$contodb = mysqli_connect('localhost', 'dbuser', 'dbpass', 'gym');
if (mysqli_connect_errno()) {
    echo "Connection to database failed!!";
} 
else {
    $un = $_POST['username'];
    $pwd = $_POST['password'];

    $query = "select * from members where username = '$un' && password = '$pwd'";
    
    $myquery = mysqli_query($contodb, $query)
    or exit("Query ERROR!");
    
    if (mysqli_num_rows($myquery) == 1) {
        $_SESSION['check'] = 'ok';
        header('location:main.php');
        exit;
    } else {
        header('location:signin.php');
        exit;
    }
}
?>