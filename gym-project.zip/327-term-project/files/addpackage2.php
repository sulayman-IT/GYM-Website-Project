<?php
session_start();

$contodb = mysqli_connect('localhost','dbuser','dbpass', 'gym');
if (mysqli_connect_errno()) {
    echo "Connection to database failed!!";
} 
else {
    $pn = $_POST['packname'];
    $st = $_POST['starttime'];
    $et = $_POST['endtime'];
    $p = $_POST['price'];
    
    $query = 'INSERT into packages(package_name, start_time, end_time, price) VALUES (?,?,?,?)';

    $stmt = mysqli_stmt_init($contodb);

    mysqli_stmt_prepare($stmt, $query) or exit('Query Error!! check your query'. mysqli_stmt_errno($stmt));
      
    mysqli_stmt_bind_param($stmt,'ssss', $pn,$et, $st,$p) or exit('Bind Param Error.');

    mysqli_stmt_execute($stmt) or exit('Query Execution failed.'. mysqli_stmt_errno($stmt));

    if (mysqli_stmt_affected_rows($stmt)==1){
        header("location:main.php");
        exit();
    }
    mysqli_stmt_close($stmt);
    mysqli_close($contodb);
}    
?>