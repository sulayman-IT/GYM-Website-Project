<?php 
include './check.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership</title>
    <style>
        body {
            background-image: url(images/image1.jpg);
            background-repeat: no-repeat;
            background-size:cover;
        }
        h1.h11{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 60px;
            font-style: italic;
            margin-left: 45px;
            
        }
        p.h1{
            font-family: "Times New Roman", Times, serif;
            color: rgb(0, 211, 211);
            font-size: 21px;
            font-style: italic;
            font-weight: bold; 
            margin-left: 25px;
        }
        h2{
            font-family: "Times New Roman", Times, serif;
            font-size: 30px;
            font-style: italic;
        }
        .cn{
            text-align: center;
        }
        form{
            background-color: rgba(0, 211, 211, 0.8);
            width:99%;
            margin: auto;
            border-radius: 25px;
        }
        a.gb{
            border: 2px solid #feffff;
            padding: 2px 10px;
            text-align: center;
            text-decoration: none;
            color: white;
            font-weight: bold;
            display: inline-block;
            font-size: 14px;
            margin-left: 35px;
        }
        a.gb:visited {
            text-decoration: none;
        }
        a.gb:link {
            text-decoration: none;
        }
        a.gb:active{
            text-decoration: none;
        }
        a.gb:hover{
            text-decoration: none;
            color: black;
            background-color: red;
            border-color: red;
        }
        .nso{
            margin-left: 15px;
        }
        table{
            width:75%;
            border-collapse: collapse;
            border-style: solid;
            border-color: black;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:nth-child(odd) {
            background-color: rgb(128, 128, 128, 0.6);
        }
        th {
            background-color:black;
            color: white;
            padding: 10px;            
        }
        td{
            text-align: center;
            padding: 8px 15px;
        }
        .membtn{
            background-color: black;
            color: white;
            padding: 5px 20px;
            border-radius: 6px;
        }
        .membtn:hover{
            background-color: #2f2f2f;
            color: white;
            border-color: #2f2f2f;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <h1 class="h11">Hyper GYM</h1>
    <p class="h1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFor body building...</p>
    <br><br>
    <form action="" method="post">
        <center>
            <br>
            <h2>Membership Packages</h2>
            <br><br>
            <table border="3">
                <tr>
                    <th>Package name</th>
                    <th>Starting time</th>
                    <th>Ending time</th>
                    <th>Price</th>
                    <th>Choose your package</th>
                </tr>
                <?php
                $contodb = mysqli_connect("localhost", "dbuser", "dbpass", "gym");
                if (mysqli_connect_errno()) {
                    echo "Connection to database failed!!";
                } 
                else {
                    $query = "SELECT package_name, start_time, end_time, price FROM packages";

                    $chquery = mysqli_query($contodb, $query)
                    or exit("Query ERROR!");

                    if (mysqli_num_rows($chquery) > 0) {
                        while ($x = mysqli_fetch_assoc($chquery)) {
                            echo "<tr>";
                            echo '<td value="' . $x["package_name"] . '">' . $x["package_name"] . "</td>";
                            echo '<td>' . $x["start_time"] . '</td>';
                            echo '<td>' . $x["end_time"] . '</td>';
                            echo '<td value="' . $x["price"] . '">' . $x["price"] . "</td>";
                            echo '<td><input type="radio" name="chosen" value="' . $x["package_name"] . ',' . $x["price"] . '"></td>';
                            echo "</tr>";
                        }
                    } else {
                        echo '<script>alert("ERROR, No rows added!!")</script>';
                    }
                    if (isset($_POST['membtn'])) {
                        $sel = $_POST['chosen'];
                        list($packname, $packprice) = explode(',', $sel);

                        $squery = "INSERT INTO operations (packageName, packagePrice) VALUES ('$packname', '$packprice')";
                        if (mysqli_query($contodb, $squery) > 0) {
                            echo '<script>alert("New row added successfully")</script>';
                        } else {
                            echo "Error: " . $squery . "<br>" . mysqli_error($contodb) . "Already added";
                        }
                        
                    }
                }
                ?>
            </table>
            <br><br>
            <button type="submit" name="membtn" class="membtn">Submit</button>
        </center>
        <br><br><br>
        <p class="nso"><b>Note some of important rules:</b></p>
        <ol type="i">
            <li>
                You will not be allow to enter if you will be late more than 15 min.
            </li>
            <li>
                You have to bring your towel. 
            </li>
            <li>
                if these packages is not suitable for you, you can create your package. <a href="addpackage.php">click here</a> for add your package.
            </li>
        </ol>
        <br>
        <a href="main.php" class="gb">Go back</a>
        <br><br>
    </form>    
</body>
</html>